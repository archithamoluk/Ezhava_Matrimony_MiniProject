<?php
	$dbhost="localhost"; 
	$dbuser="root";
	$dbpass="";
	$dbname="shubhamangal1";
	$con = mysqli_connect($dbhost,$dbuser,$dbpass,$dbname);
	
?>