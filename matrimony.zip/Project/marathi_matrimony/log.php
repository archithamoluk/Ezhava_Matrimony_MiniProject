<?php

echo $_GET["msg"];


